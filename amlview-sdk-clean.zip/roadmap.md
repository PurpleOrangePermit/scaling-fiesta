# Current tasks
- [x] Replace Russian score terminology and update the introductory wording.
- [x] Keep the report and graph within mobile screen bounds.
- [x] Remove excessive glow from pricing buttons while preserving smooth transitions.
- [x] Replace the overlay with a separate localized demonstration loading/error page, exit confirmation, and home retry without SDK.
- [x] Lock report-page scrolling and repair clipped alert shadows and error outline.
- [x] Validate wallet formats and animate localized loading stages.